#!/usr/bin/env python

import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


x_labels = ["Capacity 1","Capacity 5","Capacity 10"]
x_Axis = [1,2,3]
#y_Axis_5 = [0.75 , 1.23 ,2.08 ]
#y_Axis_10 =[0.74 ,1.2 ,1.3]
#y_Axis_5 = [0.06 , 0.2 ,0.27 ]
#y_Axis_10 =[0.05 ,0.16 ,0.24]
#y_Axis_5 = [1.33,4,4.78]
#y_Axis_10 =[1.34,4.05,7.1]
y_Axis_5 = [17 , 25, 36.2]
y_Axis_10 =[17,30.79,40.88]
nodes = ["5","10"]
capacity=["1","5","10"]
difficulty = ["4","5"]
colors = ["red","blue","green","black","yellow"]

plt.grid(True)

plt.xticks(x_Axis,x_labels,rotation=45)
#plt.set_xlim(-0.5, len(x_Axis) - 0.5)
plt.ylabel("Average Block Time")
plt.xlabel("Capacity")


plt.plot(x_Axis, y_Axis_5, label="5 nodes", color="red")
plt.plot(x_Axis, y_Axis_10, label="10 nodes", color="blue")

plt.legend(loc='upper left')
plt.title("Average Block Time plot for difficulty 5 :")
plt.savefig("block_plot_dif_5.png",bbox_inches="tight")
#plt.savefig(("output.png"),bbox_inches="tight")e
