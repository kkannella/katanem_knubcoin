import jsonpickle
import requests
from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
import Crypto
import Crypto.Random
from Crypto.Hash import SHA
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
import sys
import binascii
from _thread import *
import threading
import time
from argparse import ArgumentParser



def run_tran(var_id,second_ip):

	file_trs = open("trans"+str(int(var_id-3))+".txt", "r")

	for x in file_trs:
		#send from numba to i node monies
		tokens = x.split()
		recipient_id = int(tokens[0][-1]) 	
		amount = int(tokens[1])
		parameters={'recipient_node':recipient_id,'amount':amount}
		ra = requests.post(url='http://192.168.'+str(second_ip)+':5000/create_transactiona',json=parameters)
		result=ra.json()
		#time.sleep(0.4)
	print("Finished")
	file_trs.close()
	

if __name__ == '__main__':
	print("Starting test")
	
	start_new_thread(run_tran,(3,'0.3'))
	start_new_thread(run_tran,(4,'0.4'))
	start_new_thread(run_tran,(5,'0.5'))
	start_new_thread(run_tran,(6,'0.6'))
	start_new_thread(run_tran,(7,'0.7'))
	#
	#start_new_thread(run_tran,(8,'1.1'))
        #start_new_thread(run_tran,(9,'1.2'))
        #start_new_thread(run_tran,(10,'1.3'))
        #start_new_thread(run_tran,(11,'1.4'))
        #start_new_thread(run_tran,(12,'1.5'))

	
	time.sleep(36000)






